import { useEffect, useRef, useState } from "react";
import { Container,Row,Button } from "react-bootstrap";




function CountDown()
{
    let [times, setTimes] = useState(0)
    let [input1, setInput1]=useState(0)
    let [input2, setInput2]=useState(0)

    const id = useRef();

    const handleInput1 = (ev) =>
    {
        setInput1(input1=ev.target.value)   
    }
    const handleInput2 = (ev) =>
    {
        setInput2(input2=ev.target.value)
    }

    const handleStartButton = () =>
    {
       
        id.current = setInterval(()=>{
                setTimes((prev)=>prev+1)
                console.log(times)
            },1000)
    }

   
    useEffect(()=>{
        return ()=>clearInterval(id.current);
    },[])

    return(<>
    <br></br>
    <br></br>
            <Container>
                <center><Row style={{border:"2px solid gray", borderRadius:"15px",width:"350px",height:"250px"}}>
                   <center>
                   <h1>CountDown</h1><br></br>
                        <h2>{times}</h2>
                      <br></br><br></br>
                    <Button variant="success" onClick={()=>handleStartButton()}>Start</Button>&nbsp;&nbsp;
                    <Button variant="success" onClick={()=>clearInterval(id.current)}>Pause</Button>&nbsp;&nbsp;
                    <Button variant="success"
                    onClick={()=>{
                        clearInterval(id.current)
                        setTimes(0)
                    }}
                    >Reset</Button>
                   </center>
                </Row></center>
            </Container>
    </>)
}
export default CountDown;